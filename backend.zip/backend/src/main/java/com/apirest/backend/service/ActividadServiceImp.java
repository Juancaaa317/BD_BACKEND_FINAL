package com.apirest.backend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apirest.backend.model.Actividad;
import com.apirest.backend.repository.IActividadRepository;
import com.apirest.backend.repository.IUsuarioRepository;



@Service
public class ActividadServiceImp implements IActividadService {

    @Autowired IActividadRepository actividadRepository;
    @Autowired IUsuarioRepository usuarioRepositoy;

    
    public Actividad guardarActividad(Actividad actividad){
        
        if (!usuarioRepositoy.existsById(actividad.getIdUsuario_propone().getIdUsuario())) {
            throw new RuntimeException("Error! El usuario que propone no existe.");
        }
        
        

        Rol rol = actividad.getIdUsuario_propone().getRol();
        if (rol==("participante")) {
            throw new RuntimeException("Error! Un participante no puede proponer actividades.");
        }
        return actividadRepository.save(actividad);

    }

    @Override
    public List<Actividad> listarActividades() {
        throw new UnsupportedOperationException("Unimplemented method 'listarActividades'");
    }
}
